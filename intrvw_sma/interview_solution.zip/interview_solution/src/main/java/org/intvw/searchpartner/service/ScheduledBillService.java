/* *************************************************************
 *
 * COPYRIGHT (c) 2018-19 Saurabh Agrawal
 * All Rights Reserved. Saurabh Agrawal - Confidential.
 *
 * Date : Aug 04, 2018
 *
 * *************************************************************/
package org.intvw.searchpartner.service;

/**
 * Scheduled Bill Service Interface
 * 
 * @author saurabh_agrawal
 *
 */
public interface ScheduledBillService {
	public void scheduleTaskWithCronExpression();
}
