/* *************************************************************
 *
 * COPYRIGHT (c) 2018-19 Saurabh Agrawal
 * All Rights Reserved. Saurabh Agrawal - Confidential.
 *
 * Date : Aug 04, 2018
 *
 * *************************************************************/
package org.intvw.searchpartner.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

/**
 * 
 * @author saurabh_agrawal
 *
 */
@Configuration
@EnableScheduling
@ComponentScan(basePackages = {"org.intvw.searchpartner"})
@PropertySource({ "classpath:engine.properties" })
public class AppConfig {
	@Bean
	public ObjectMapper objectMapper() {
		return new ObjectMapper();	
	}
	
	@Bean
	public XmlMapper xmlMapper() {
		return new XmlMapper();
	}
}
