package org.intvw.searchpartner.model;

public interface Convertable {
}
